<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "db_matkul";

$koneksi = mysqli_connect($host, $user, $password, $database)
?>
