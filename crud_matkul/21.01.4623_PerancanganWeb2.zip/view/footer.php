
<script src="view/bootstrap/js/bootstrap.min.js"></script>
</body>

</html>